(function () {
  'use strict';
  var AllDogs = (window.AllDogs = window.AllDogs || {});

  var BLOCK = AllDogs.blocks.BLOCK;
  var WORLD_SIZE = AllDogs.constants.WORLD_SIZE;
  var WORLD_HEIGHT = AllDogs.constants.WORLD_HEIGHT;

  function hash2(x, z) {
    var h = (Math.imul(x, 374761393) + Math.imul(z, 668265263)) | 0;
    h = (h ^ (h >>> 13)) | 0;
    h = Math.imul(h, 1274126177);
    h = (h ^ (h >>> 16)) >>> 0;
    return h / 4294967295;
  }

  function smoothNoise(x, z) {
    var ix = Math.floor(x);
    var iz = Math.floor(z);
    var fx = x - ix;
    var fz = z - iz;
    var a = hash2(ix, iz);
    var b = hash2(ix + 1, iz);
    var c = hash2(ix, iz + 1);
    var d = hash2(ix + 1, iz + 1);
    var top = a + (b - a) * fx;
    var bottom = c + (d - c) * fx;
    return top + (bottom - top) * fz;
  }

  function fbm(x, z, octaves) {
    var amp = 1;
    var freq = 1;
    var sum = 0;
    var norm = 0;
    for (var i = 0; i < octaves; i++) {
      sum += smoothNoise(x * freq, z * freq) * amp;
      norm += amp;
      amp *= 0.5;
      freq *= 2;
    }
    return sum / norm;
  }

  class TestingZone extends AllDogs.Zone {
    constructor() {
      super('testing', 'Testing Zone');
    }

    heightAt(x, z) {
      return Math.round(3 + fbm(x * 0.09 + 41, z * 0.09 + 41, 3) * 5);
    }

    generate(world) {
      var S = WORLD_SIZE;
      world.clear();

      for (var x = 0; x < S; x++) {
        for (var z = 0; z < S; z++) {
          var h = this.heightAt(x, z);

          for (var y = 0; y <= h; y++) {
            var b = BLOCK.STONE;
            if (y === 0) b = BLOCK.BEDROCK;
            else if (y > h - 3) b = BLOCK.DIRT;
            if (y === h) b = BLOCK.GRASS;
            world.set(x, y, z, b);
          }

          if (h >= 4 && hash2(x * 5 + 31, z * 5 + 57) > 0.975) {
            this.growTree(world, x, h, z);
          }

          if (hash2(x * 3 + 77, z * 3 + 11) > 0.995) {
            this.sandPatch(world, x, h, z);
          }
        }
      }

      var cx = Math.floor(S / 2);
      var cz = Math.floor(S / 2);
      var sy = this.heightAt(cx, cz);
      this.spawn = { x: cx + 0.5, y: sy + 3, z: cz + 0.5 };

      for (var dx = -2; dx <= 2; dx++) {
        for (var dz = -2; dz <= 2; dz++) {
          for (var y = sy; y <= this.spawn.y + 1; y++) {
            world.set(cx + dx, y, cz + dz, BLOCK.AIR);
          }
        }
      }
    }

    growTree(world, x, ground, z) {
      var r = hash2(x * 11 + 17, z * 11 + 29);
      var trunk = 4 + Math.floor(r * 3);
      var top = ground + trunk;

      for (var y = 0; y < trunk; y++) {
        world.set(x, ground + 1 + y, z, BLOCK.LOG);
      }

      for (var dy = -1; dy <= 2; dy++) {
        var rad = dy <= 0 ? 2 : dy === 1 ? 1 : 0;
        for (var dx = -rad; dx <= rad; dx++) {
          for (var dz = -rad; dz <= rad; dz++) {
            var ax = x + dx;
            var ay = top + dy;
            var az = z + dz;
            if (ax < 0 || az < 0 || ax >= WORLD_SIZE || az >= WORLD_SIZE) continue;
            if (ay < 0 || ay >= WORLD_HEIGHT) continue;
            if (world.get(ax, ay, az) !== BLOCK.AIR) continue;
            world.set(ax, ay, az, BLOCK.LEAVES);
          }
        }
      }
    }

    sandPatch(world, x, h, z) {
      for (var dx = -1; dx <= 1; dx++) {
        for (var dz = -1; dz <= 1; dz++) {
          var ax = x + dx;
          var az = z + dz;
          if (ax < 0 || az < 0 || ax >= WORLD_SIZE || az >= WORLD_SIZE) continue;
          if (world.get(ax, h, az) === BLOCK.GRASS) world.set(ax, h, az, BLOCK.SAND);
        }
      }
    }

    entities() {
      var x = Math.floor(this.spawn.x) + 4;
      var z = Math.floor(this.spawn.z);
      var gy = this.heightAt(x, z) + 1;
      var dx = this.spawn.x - (x + 0.5);
      var dz = this.spawn.z - (z + 0.5);
      var cx = x + 3;
      var cz = z + 3;
      return [
        {
          type: 'sign',
          pos: { x: x + 0.5, y: gy, z: z + 0.5 },
          text: ['All Dogs Go', 'To Minecraft'],
          yaw: Math.atan2(-dx, -dz)
        },
        {
          type: 'chest',
          pos: { x: cx + 0.5, y: this.heightAt(cx, cz) + 1, z: cz + 0.5 },
          yaw: Math.atan2(this.spawn.x - (cx + 0.5), this.spawn.z - (cz + 0.5))
        }
      ];
    }
  }

  AllDogs.TestingZone = TestingZone;
})();